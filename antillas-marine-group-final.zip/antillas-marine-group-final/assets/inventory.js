(() => {
  const grid = document.getElementById('inventory-grid');
  const empty = document.getElementById('inventory-empty');
  const toolbar = document.getElementById('inventory-toolbar');
  const search = document.getElementById('inventory-search');
  const typeFilter = document.getElementById('type-filter');
  const statusFilter = document.getElementById('status-filter');
  const modal = document.getElementById('boat-modal');
  const modalContent = document.getElementById('boat-modal-content');
  let boats = [];

  fetch('/data/inventory.json', { cache: 'no-store' })
    .then(r => r.ok ? r.json() : { boats: [] })
    .then(data => {
      boats = Array.isArray(data.boats) ? data.boats.filter(b => b && b.published !== false) : [];
      if (!boats.length) return;
      empty.hidden = true;
      toolbar.hidden = false;
      populateTypes();
      render();
    })
    .catch(() => {});

  [search, typeFilter, statusFilter].forEach(el => el?.addEventListener('input', render));

  function populateTypes() {
    const types = [...new Set(boats.map(b => b.type).filter(Boolean))].sort();
    types.forEach(type => {
      const option = document.createElement('option');
      option.value = type;
      option.textContent = type;
      typeFilter.appendChild(option);
    });
  }

  function render() {
    const q = (search?.value || '').toLowerCase().trim();
    const type = typeFilter?.value || '';
    const status = statusFilter?.value || '';
    const filtered = boats.filter(b => {
      const haystack = `${b.year || ''} ${b.make || ''} ${b.model || ''} ${b.type || ''}`.toLowerCase();
      return (!q || haystack.includes(q)) && (!type || b.type === type) && (!status || b.status === status);
    });

    grid.innerHTML = filtered.length ? filtered.map(cardTemplate).join('') : `<div class="inventory-empty" style="grid-column:1/-1;min-height:220px"><h3>No boats match those filters.</h3><p>Try another search or clear a filter.</p></div>`;
    grid.querySelectorAll('[data-boat-index]').forEach(card => {
      card.addEventListener('click', () => openBoat(Number(card.dataset.boatIndex)));
      card.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openBoat(Number(card.dataset.boatIndex)); }
      });
    });
  }

  function cardTemplate(boat) {
    const idx = boats.indexOf(boat);
    const title = escapeHtml([boat.year, boat.make, boat.model].filter(Boolean).join(' '));
    const image = safeImage(boat.main_image);
    const status = escapeHtml(boat.status || 'Available');
    const statusClass = status.toLowerCase().includes('pending') ? 'pending' : status.toLowerCase() === 'sold' ? 'sold' : '';
    return `<article class="boat-card" tabindex="0" role="button" data-boat-index="${idx}" aria-label="View ${title}">
      <div class="boat-card-image">${image ? `<img src="${image}" alt="${title}" loading="lazy">` : ''}<span class="boat-status ${statusClass}">${status}</span></div>
      <div class="boat-card-body">
        <h3>${title}</h3>
        <div class="boat-meta">${boat.type ? `<span>${escapeHtml(boat.type)}</span>` : ''}${boat.length ? `<span>${escapeHtml(boat.length)}</span>` : ''}${boat.location ? `<span>${escapeHtml(boat.location)}</span>` : ''}</div>
        <div class="boat-price"><strong>${formatPrice(boat.price, boat.currency)}</strong><span>View details →</span></div>
      </div>
    </article>`;
  }

  function openBoat(index) {
    const boat = boats[index];
    if (!boat || !modal || !modalContent) return;
    const title = escapeHtml([boat.year, boat.make, boat.model].filter(Boolean).join(' '));
    const image = safeImage(boat.main_image);
    const features = Array.isArray(boat.features) ? boat.features.filter(Boolean) : [];
    modalContent.innerHTML = `
      <div class="boat-modal-gallery">${image ? `<img src="${image}" alt="${title}">` : ''}</div>
      <div class="boat-modal-body">
        <div class="modal-heading"><div><p class="eyebrow dark">${escapeHtml(boat.status || 'Available')}</p><h2>${title}</h2></div><div class="modal-price">${formatPrice(boat.price, boat.currency)}</div></div>
        <div class="modal-specs">
          <div><span>Type</span><strong>${escapeHtml(boat.type || '—')}</strong></div>
          <div><span>Length</span><strong>${escapeHtml(boat.length || '—')}</strong></div>
          <div><span>Engine(s)</span><strong>${escapeHtml(boat.engines || '—')}</strong></div>
          <div><span>Hours</span><strong>${escapeHtml(boat.hours || '—')}</strong></div>
        </div>
        ${boat.description ? `<p class="modal-description">${escapeHtml(boat.description)}</p>` : ''}
        ${features.length ? `<ul class="feature-list">${features.map(f => `<li>${escapeHtml(typeof f === 'string' ? f : f.item || '')}</li>`).join('')}</ul>` : ''}
        <div class="modal-cta"><p>Interested in this boat? Reference <strong>${escapeHtml(boat.stock_number || title)}</strong> when you contact us.</p><a class="button button-dark" href="#contact" id="modal-contact">Inquire About This Boat</a></div>
      </div>`;
    modal.showModal();
    document.body.classList.add('modal-open');
    document.getElementById('modal-contact')?.addEventListener('click', () => {
      modal.close(); document.body.classList.remove('modal-open');
      const select = document.getElementById('interest-select'); if (select) select.value = 'A listed boat';
      setTimeout(() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }), 0);
    });
  }

  function formatPrice(value, currency) {
    if (value === null || value === undefined || value === '') return 'Call for Price';
    const num = Number(String(value).replace(/[^0-9.]/g, ''));
    if (!Number.isFinite(num)) return escapeHtml(String(value));
    try { return new Intl.NumberFormat('en-US', { style:'currency', currency: currency || 'USD', maximumFractionDigits:0 }).format(num); }
    catch { return `$${num.toLocaleString('en-US')}`; }
  }

  function safeImage(path) {
    if (!path) return '';
    const s = String(path).trim();
    if (s.startsWith('/') || s.startsWith('https://') || s.startsWith('http://')) return escapeAttr(s);
    return '/' + escapeAttr(s.replace(/^\/+/, ''));
  }

  function escapeHtml(v) { return String(v ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
  function escapeAttr(v) { return escapeHtml(v).replace(/`/g, '&#96;'); }
})();
