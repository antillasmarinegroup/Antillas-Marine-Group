(() => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.primary-nav');
  const modal = document.getElementById('boat-modal');

  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(open));
      navToggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
    });
    nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      nav.classList.remove('open');
      navToggle.setAttribute('aria-expanded', 'false');
    }));
  }

  document.querySelectorAll('[data-subject]').forEach(link => {
    link.addEventListener('click', () => {
      const select = document.getElementById('interest-select');
      if (select) select.value = 'Selling / consigning a boat';
    });
  });

  const closeModal = () => {
    if (modal?.open) modal.close();
    document.body.classList.remove('modal-open');
  };
  document.querySelector('.modal-close')?.addEventListener('click', closeModal);
  modal?.addEventListener('click', e => { if (e.target === modal) closeModal(); });
  modal?.addEventListener('close', () => document.body.classList.remove('modal-open'));

  const reveal = new IntersectionObserver(entries => {
    entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add('is-visible'); });
  }, { threshold: .12 });
  document.querySelectorAll('.reveal').forEach(el => reveal.observe(el));

  document.getElementById('year').textContent = new Date().getFullYear();

  fetch('/data/settings.json', { cache: 'no-store' })
    .then(r => r.ok ? r.json() : null)
    .then(settings => {
      if (!settings) return;
      if (settings.location) document.getElementById('location-display').textContent = settings.location;

      const phoneRow = document.getElementById('phone-row');
      const phone = document.getElementById('phone-display');
      if (settings.phone && phoneRow && phone) {
        phoneRow.hidden = false;
        phone.textContent = settings.phone;
        phone.href = `tel:${settings.phone.replace(/[^+\d]/g, '')}`;
      }

      const emailRow = document.getElementById('email-row');
      const email = document.getElementById('email-display');
      if (settings.email && emailRow && email) {
        emailRow.hidden = false;
        email.textContent = settings.email;
        email.href = `mailto:${settings.email}`;
      }

      const social = document.getElementById('social-links');
      const links = [];
      if (settings.instagram) links.push(`<a href="${safeUrl(settings.instagram)}" target="_blank" rel="noopener" aria-label="Instagram">IG</a>`);
      if (settings.facebook) links.push(`<a href="${safeUrl(settings.facebook)}" target="_blank" rel="noopener" aria-label="Facebook">FB</a>`);
      if (settings.whatsapp) {
        const n = String(settings.whatsapp).replace(/\D/g, '');
        links.push(`<a href="https://wa.me/${n}" target="_blank" rel="noopener" aria-label="WhatsApp">WA</a>`);
      }
      if (social) social.innerHTML = links.join('');
    })
    .catch(() => {});

  if (window.netlifyIdentity) {
    window.netlifyIdentity.on('init', user => {
      if (!user && window.location.hash.includes('invite_token')) window.netlifyIdentity.open('signup');
    });
  }

  function safeUrl(url) {
    try {
      const parsed = new URL(url);
      return ['http:', 'https:'].includes(parsed.protocol) ? parsed.href : '#';
    } catch { return '#'; }
  }
})();
