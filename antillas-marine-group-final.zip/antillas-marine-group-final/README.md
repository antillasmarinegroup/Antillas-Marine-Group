# Antillas Marine Group Website

A production-ready static website for a Puerto Rico-based used-boat dealer. It includes a browser-based inventory CMS at `/admin/`, an inventory data feed, responsive design, SEO basics, and a Netlify-ready contact form.

## What is included

- Responsive public dealer website
- Empty inventory state for launch with no active boats
- Inventory search and filters that automatically appear once boats are published
- Boat detail modal with price, specifications, description, features, and inquiry CTA
- `/admin/` content management panel powered by Decap CMS
- Inventory fields for status, year, make, model, type, length, price, engines, hours, location, photos, description, and features
- Editable business phone, email, WhatsApp, Instagram, and Facebook
- Official Antillas Marine Group logo and favicon included
- Netlify Forms contact form
- Thank-you and 404 pages
- Security headers through `netlify.toml`

## Fastest deployment path: GitHub + Netlify

1. Create a new GitHub repository and upload all files in this folder to the repository root.
2. In Netlify, choose **Add new project → Import an existing project** and connect the GitHub repository.
3. No build command is required. The publish directory is `.` and is already set in `netlify.toml`.
4. Deploy the site.
5. In the Netlify project dashboard, enable **Netlify Identity**.
6. Set registration to **Invite only**.
7. Enable **Git Gateway** under the Identity services/settings.
8. Invite yourself as an Identity user.
9. Visit `https://YOUR-DOMAIN/admin/`, sign in, and open **Inventory → Boat Inventory**.
10. Add a boat and click **Publish**. Decap saves the inventory data to the Git repository, Netlify redeploys, and the listing appears on the public site.

### Important 2026 note about Git Gateway

This project is configured with `git-gateway` because it remains one of the easiest non-technical admin setups and works with Netlify Identity. Netlify now labels Git Gateway as deprecated and does not recommend it for new long-term architectures. The public website is independent of that backend, so you can later switch the CMS authentication/backend without rebuilding the site. Decap's current hosted alternative is **Decap Turbo**, or you can configure Decap's GitHub backend with OAuth.

## Before going live

The launch contact information is already loaded:

- **Phone:** (787) 505-2350
- **Email:** Sales@antillasmarine.com
- **Location:** Puerto Rico

You can change these at any time in `/admin/` under **Site Settings → Contact & Social**. Blank social or WhatsApp fields are automatically hidden from the public website.

You should also:

- Connect your custom domain in Netlify.
- Verify that Netlify Forms is receiving submissions under **Forms**.
- Add your first inventory listing only when you have a boat ready to publish.
- Add Instagram, Facebook, and WhatsApp in Site Settings if desired.
- Replace or expand the wording if you want to offer financing, trade-ins, brokerage, surveys, transport, or other services.

## Inventory behavior

Inventory lives in `data/inventory.json`. The site initially ships with:

```json
{ "boats": [] }
```

When no boats are published, visitors see a deliberate "New listings are on the way" message. Once at least one boat is published, the page automatically switches to a searchable inventory grid.

## Local preview

From this folder, run:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080`.

The public site will work locally. The CMS needs its authentication backend when deployed; Decap's `local_backend: true` is included for developers who want to run a local proxy.

## File map

- `index.html` — public website
- `assets/styles.css` — all website styling
- `assets/site.js` — navigation, settings, interactions
- `assets/inventory.js` — inventory rendering and filters
- `data/inventory.json` — boat inventory data
- `data/settings.json` — editable contact/social settings
- `admin/index.html` — CMS panel entry point
- `admin/config.yml` — CMS fields and backend configuration
- `uploads/` — CMS boat photos
- `netlify.toml` — Netlify deployment settings

## Optional next upgrades

The current version is intentionally lightweight and inexpensive to operate. Good next upgrades are a dedicated boat detail URL for every listing, CRM/email lead routing, financing/pre-qualification integration, bilingual English/Spanish content, and structured data for each vessel.
